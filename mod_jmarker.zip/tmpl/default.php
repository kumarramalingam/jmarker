
<?php
/*------------------------------------------------------------------------
# mod_jmarker
# ------------------------------------------------------------------------
# author    Kumar Ramalingam - http://www.w3cert.in
# mail      kumar@w3cert.in
# copyright Copyright (C) 2012 W3cert.in All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://w3cert.in
-------------------------------------------------------------------------*/

// No direct access
defined('_JEXEC') or die;

$doc = JFactory::getDocument();
$doc->addStyleSheet(JUri::root().'modules/mod_jmarker/media/css/style.css');
$doc->addStyleSheet(JUri::root().'modules/mod_jmarker/media/css/jqueryui.css');
$doc->addScript(JUri::root().'/modules/mod_jmarker/media/js/jquery-1.9.1.min.js');
$doc->addScript(JUri::root().'/modules/mod_jmarker/media/js/jquery-ui.js');
$doc->addScript(JUri::root().'/modules/mod_jmarker/media/js/gmap3.js');
?>
<!-- <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=false"></script> -->
<script src="http://maps.google.com/maps/api/js?v=3&libraries=geometry"></script>
<!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
-->
<!-- <script src="http://code.jquery.com/ui/1.8.21/jquery-ui.min.js"></script>
-->

<div id="map" style="height: 400px;" class="span12"></div>
<input type="text" name="distance" id="distance" value="">
<input type="button" name="search" id="search" onclick="getDistance()" value="search">
<input type="checkbox" name="Lab" value="">Lab
<input type="checkbox" name="Lab" value="">Park
<!-- <div id="slider"></div> -->
<div id="slider" class="slider"></div>
<p><span id="slider-value"></span> Km </p>
<select id="geodistance" name="geodistance">
	<option value="10">10 KM</option>
	<option value="20">20 KM</option>
	<option value="30">30 KM</option>
	<option value="40">40 KM</option>
	<option value="50">50 KM</option>
	<option value="60">60 KM</option>
	<option value="70">70 KM</option>
	<option value="80">80 KM</option>
	<option value="90">90 KM</option>
	<option value="100">100 KM</option>
</select>	
<!-- <input class="span6" id="geoaddress" type="text" value="Enter an address..."
                       onblur="if (this.value=='') {this.value='Enter an address...';jQuery('#fp_searchAddressBtn').attr('disabled', true);}"
                       onfocus="if (this.value=='Enter an address...') this.value='';jQuery('#fp_searchAddressBtn').attr('disabled', false);">
-->
<input class="span6" id="geoaddress" type="text" value="" placeholder="Enter City,State or Zipcode..">
<input type="button" id="fp_searchAddressBtn" value="search" class="btn" onclick="codeAddress()">
<script>
jQuery(function() {	
   var markersData = {
        values: [{
            latLng: [51.506695, -0.147950],
            options: {
                icon: "http://maps.google.com/mapfiles/kml/paddle/blu-circle.png",
            },
            data: 'aaabbb',
            tag: "aaa"
        }, ],
        options: {
            draggable: false
        }
    };
    
    var locations = jQuery.parseJSON('<?php echo json_encode($finaldatas) ?>');
    
    console.log(locations);
    
     /*var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 10,
      center: new google.maps.LatLng(-33.92, 151.25),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });*/
    
  // Try HTML5 geolocation
  if(navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(function(position) {
      var pos = new google.maps.LatLng(position.coords.latitude,
                                       position.coords.longitude);
      map.setCenter(pos);
    }, function() {
      handleNoGeolocation(true);
    });
  } else {
    // Browser doesn't support Geolocation
    handleNoGeolocation(false);
  }	
		
  jQuery("#slider").slider({
        range: "min",
        value: 1,
        min: 1,
        max: 100,
        slide: function (event, ui) {
            computedistance(ui.value);
            jQuery("#slider-value").html(ui.value);  
            jQuery("#slider-distance").html(ui.value);          
        }
    }).slider("option", "slide").call(jQuery("#slider"), null, {
        value: jQuery("#slider").slider("value")
    });  
    
   jQuery("#slider-value").html(jQuery('#slider').slider('value'));
   
   function computedistance(km) {
	      
	    console.log(km);
	    
	    console.log(locations[0][7]);    

        var markers = jQuery("#map").gmap3({
            get: {
                name: "marker",
                all: true
            }
        }),
           user = new google.maps.LatLng(locations[0][8],          
           locations[0][9]),
           map = jQuery("#map").gmap3({
                get: {
                    name: 'map'
                }
           });
        jQuery.each(markers, function (i, m) {
            m.setMap((google.maps.geometry.spherical.computeDistanceBetween(user, m.getPosition()) <= km * 1000) ? map : null);
        });
   }  
});
    
    var gmarkers = [];
    var circle = null;
	
	var distance;	

	
	 var gmarkers = []; 

     // global "map" variable
     
      var circle = null;
      var geocoder = new google.maps.Geocoder();
		
	var countlatlngs = '<?php echo $countlnglats ?>';
		
	//console.log(jsonlocations[1][0]);
	//console.log(countlatlngs);
	
	//var locations = jQuery.parseJSON('<?php echo json_encode($finalnglats) ?>');
	
	var locations = jQuery.parseJSON('<?php echo json_encode($finaldatas) ?>');
	
	console.log(locations);
			
    /*var locations = [
      ['<?php echo $markerone ?>','<?php echo $markeronelat ?>','<?php echo $markeronelng ?>' ],
      ['<?php echo $markertwo ?>','<?php echo $markertwolat ?>','<?php echo $markertwolng ?>'],
      ['<?php echo $markerthree ?>','<?php echo $markerthreelat ?>','<?php echo $markerthreelng ?>'],
      ['<?php echo $markerfour ?>','<?php echo $markerfourlat ?>','<?php echo $markerfourlng?>']
    ];*/
       
    //locations = jsonlocations;
    
    geocoder = new google.maps.Geocoder();
             
    var map = new google.maps.Map(document.getElementById('map'), {
      zoom: 10,
      center: new google.maps.LatLng(-33.92, 151.25),
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });    
    
  function codeAddresses() {
  var address = document.getElementById('geoaddress').value;
  var radius = parseInt(document.getElementById('geodistance').value, 10)*1000;
  
  console.log(address);
  console.log(radius);
  geocoder.geocode( { 'address': address}, function(results, status) {
    if (status == google.maps.GeocoderStatus.OK) {
      map.setCenter(results[0].geometry.location);
      var marker = new google.maps.Marker({
        position: results[0].geometry.location
      });
      if (circle) circle.setMap(null);
      circle = new google.maps.Circle({center:marker.getPosition(),
                                     radius: radius,
                                     fillOpacity: 0.35,
                                     fillColor: "#FF0000",
                                     map: map});
      var bounds = new google.maps.LatLngBounds();
      for (var i=0; i<gmarkers.length;i++) {
        if (google.maps.geometry.spherical.computeDistanceBetween(gmarkers[i].getPosition(),marker.getPosition()) < radius) {
          bounds.extend(gmarkers[i].getPosition())
          gmarkers[i].setMap(map);
        } else {
          gmarkers[i].setMap(null);
        }
      }
      map.fitBounds(bounds);
    } else {
      alert('Geocode was not successful for the following reason: ' + status);
    }
  });
}
   
  function codeAddressDemo() {
		var geoaddress = document.getElementById("geoaddress").value;
        console.log(geoaddress);
        geocoder.geocode({ 'address': geoaddress}, function (results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                map.setCenter(results[0].geometry.location);
                map.setZoom(12);                
            } else {
                alert("Geocode was not successful for the following reason: " + status);
            }
        });
    }    

    // Setup the different icons and shadows
    var iconURLPrefix = 'http://maps.google.com/mapfiles/ms/icons/';
    
    var icons = [
      iconURLPrefix + 'red-dot.png',
      iconURLPrefix + 'green-dot.png',
      iconURLPrefix + 'blue-dot.png',
      iconURLPrefix + 'orange-dot.png',
      iconURLPrefix + 'purple-dot.png',
      iconURLPrefix + 'pink-dot.png',      
      iconURLPrefix + 'yellow-dot.png'
    ]
    
    var iconCounter = 0;
       
    var infowindow = new google.maps.InfoWindow();
    var marker, i;
    for (i = 0; i < countlatlngs; i++) {  
        marker = new google.maps.Marker({
        position: new google.maps.LatLng(locations[i][9], locations[i][8]),
        icon: icons[iconCounter],
        map: map,
        radius: '100',
        animation: google.maps.Animation.DROP
    });     
            
    google.maps.event.addListener(marker, 'click', (function(marker, i) {		
        return function() {		  
		  if (marker.getAnimation() != null) {
			marker.setAnimation(null);
		  } else {
			marker.setAnimation(google.maps.Animation.BOUNCE);
		  }	
		  	  
		  var contents = "Title        :" + locations[i][0] + "<br/>" + 
		                 "Contact Name :" + locations[i][1] + "<br/>" +
		                 "Email        :" + locations[i][2] + "<br/>" +
		                 "Address      :" + locations[i][3] + "<br/>" + locations[i][4] + "<br/>" + locations[i][5] + "<br/>" +
		                 "Mobile       :" + locations[i][6] + "<br/>";		                 
		                 
          console.log(contents);
			
          infowindow.setContent(contents);        
        
          infowindow.open(map, marker);
                   
            var lat = marker.latLng.lat();
			var lng = marker.latLng.lng();
			var R = 6371; // radius of earth in km
			var distances = [];
			var closest = -1;
			for( i=0;i<map.countlatlngs; i++ ) {
				var mlat = map.locations[i].position.lat();
				var mlng = map.locations[i].position.lng();
				var dLat  = rad(mlat - lat);
				var dLong = rad(mlng - lng);
				var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
					Math.cos(rad(lat)) * Math.cos(rad(lat)) * Math.sin(dLong/2) * Math.sin(dLong/2);
				var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
				var d = R * c;
				distances[i] = d;
				if ( closest == -1 || d < distances[closest] ) {
					closest = i;
				}
			}
        }
      })(marker, i));
      iconCounter++;
     
        function rad(x) {return x*Math.PI/180;}
		
    }
    
  function codeAddress() {	  
   var address = document.getElementById('geoaddress').value;
   var slideradius = document.getElementById('slider-value').value;
   
   var radius = parseInt(document.getElementById('geodistance').value, 10)*1000;
        geocoder.geocode({ 'address': address}, function(results, status) {
          if (status == google.maps.GeocoderStatus.OK) {
            
            map.setCenter(results[0].geometry.location);
            var searchCenter = results[0].geometry.location;
            
            console.log(searchCenter);
                               
            /*
            var marker = new google.maps.Marker({
                map: map,
                position: results[0].geometry.location
            });
            */
            
            //console.log(marker);
            
         
                       
        if (circle) circle.setMap(null);
                       
        circle = new google.maps.Circle({center:searchCenter,
                                             radius: radius,
                                             fillOpacity: 0.10,
                                             fillColor: "#2AE6F8",
                                             
                                             strokeColor: "#2AE6F8",
											 strokeOpacity: 0.50,
											 strokeWeight: 2,											 
                                             map : map
                                             
                                             });
                                             
            //circle.bindTo('map', marker);                         
                                             
            //circle.setMap(map);                                 
                                                         
           //circle.bindTo('map',map);                                          
                                             
           var circlemarker = isMarkerInArea(circle,marker);   
                         
           var bounds = new google.maps.LatLngBounds();
                     
           map.fitBounds(bounds); 
                    
           //console.log(bounds);
	       var foundMarkers = 0;
	    
	       //float[] distance = new float[2];    
	    
            for (var i=0; i<gmarkers.length;i++) {
              if (google.maps.geometry.spherical.computeDistanceBetween(gmarkers[i].getPosition(),searchCenter) < radius) {
                bounds.extend(gmarkers[i].getPosition())
                gmarkers[i].setMap(map);
               
		        foundMarkers++;
              } else {
                gmarkers[i].setMap(null);
              }
            }          
            
            // put the assembled side_bar_html contents into the side_bar div
            //document.getElementById("side_bar").innerHTML = side_bar_html;
            //console.log(foundMarkers);
            
            if (foundMarkers > 0) {				
				
              map.fitBounds(bounds);
	        } else {
              map.fitBounds(circle.getBounds());
            }
            // makeSidebar();
            //google.maps.event.addListenerOnce(map, 'bounds_changed', makeSidebar);
           
          } else {
            alert('Geocode was not successful for the following reason: ' + status);
          }
        });
}

function isMarkerInArea(circle, marker){
   return (circle.getBounds().contains(marker.getPosition()));
};
  </script>
